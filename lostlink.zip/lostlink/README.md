# 🎒 LostLink — Campus Lost & Found Management System

A production-inspired REST API for managing lost and found reports on a
college campus, built with Flask, SQLAlchemy and a lightweight vanilla-JS
frontend that consumes the API. The backend is the product; the frontend
is a thin demonstration client and can be deleted without breaking the API.

---

## Overview

Students currently rely on WhatsApp groups, security offices, or word of
mouth to recover lost belongings. LostLink centralizes this into one
system: students report lost or found items, browse and search reports,
submit claims on found items, and track claim status — while campus staff
review and approve the correct claim through an admin dashboard.

---

## Features

**Student-facing**
- Report a lost item or a found item
- Browse all reports with search (title, description, category, location)
- Filter by type (lost/found), status (open/claimed/returned), category, location
- View full item detail
- Submit a claim on a found item, with a reason
- Track a claim's status by claim ID

**Admin**
- Simple key-based authentication (`X-Admin-Key` header)
- Approve or reject pending claims
- Approving a claim automatically rejects every other pending claim on that item
- Mark items as returned (closes the report)
- Delete fake / invalid reports
- Dashboard statistics (reports, returns, pending/approved claims)

**API-level**
- Consistent JSON envelope: `{ success, message, data, meta }` on success,
  `{ success: false, error }` on failure
- Centralized error handling — no stack traces are ever leaked
- Proper HTTP status codes throughout (200, 201, 400, 401, 404, 409, 500)
- Pagination, search and multi-field filtering on `GET /items`

---

## Architecture

LostLink uses the **Flask application factory pattern** with **Blueprints**,
separating concerns into distinct layers instead of a single `app.py`:

```
routes/     → HTTP layer only: parse request, call a service, return a response
services/   → business logic: validation orchestration, state transitions, rules
models/     → SQLAlchemy ORM models (Item, Claim) — no raw SQL anywhere
utils/      → validators, custom exceptions, response helpers, decorators
templates/  → Jinja2 pages that render the frontend shell
static/     → CSS + vanilla JS that calls the REST API via fetch()
```

This means the backend is fully functional and independently testable even
if the `templates/` and `static/` folders are removed — the frontend exists
purely to demonstrate the API.

### Request flow

```
Client → Blueprint route → Service function → SQLAlchemy Model → DB
                                ↓ (raises APIError subclasses on failure)
                          Centralized error handler → JSON error response
```

---

## Folder Structure

```
lostlink/
├── run.py                     # entry point — python run.py
├── config.py                  # environment-based configuration
├── requirements.txt
├── .env.example
├── .gitignore
├── app/
│   ├── __init__.py            # application factory, error handlers
│   ├── extensions.py          # db, cors instances
│   ├── models/
│   │   ├── item.py            # Item model + ItemType/ItemStatus constants
│   │   └── claim.py           # Claim model + ClaimStatus constants
│   ├── routes/
│   │   ├── main.py            # frontend page routes
│   │   ├── items.py           # /api/items endpoints
│   │   ├── claims.py          # /api/claims endpoints
│   │   ├── stats.py           # /api/stats endpoint
│   │   └── admin.py           # /api/admin/* endpoints
│   ├── services/
│   │   ├── item_service.py    # item business logic
│   │   └── claim_service.py   # claim business logic + auto-reject rule
│   ├── utils/
│   │   ├── validators.py      # field validation + category/location lists
│   │   ├── errors.py          # APIError, ValidationError, NotFoundError…
│   │   ├── responses.py       # success() JSON envelope helper
│   │   └── decorators.py      # @admin_required
│   ├── templates/
│   │   ├── base.html
│   │   ├── index.html
│   │   ├── report.html
│   │   ├── browse.html
│   │   ├── item_detail.html
│   │   ├── track_claim.html
│   │   └── admin.html
│   └── static/
│       ├── css/style.css
│       └── js/
│           ├── api.js         # fetch wrapper + toast helper
│           ├── home.js
│           ├── report.js
│           ├── browse.js
│           ├── item_detail.js
│           ├── track.js
│           └── admin.js
```

---

## Installation

### 1. Clone / open the project folder in VS Code

### 2. Create a virtual environment

```bash
python -m venv venv
```

Activate it:

- Windows: `venv\Scripts\activate`
- macOS/Linux: `source venv/bin/activate`

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure environment variables (optional)

Copy `.env.example` to `.env` and adjust as needed:

```bash
cp .env.example .env
```

```
SECRET_KEY=change-this-secret-key
ADMIN_KEY=admin123
DATABASE_URL=sqlite:///lostlink.db
FLASK_ENV=development
```

If you skip this step, sensible development defaults are used automatically
(admin key defaults to `admin123`).

### 5. Run the application

```bash
python run.py
```

Visit **http://127.0.0.1:5000** in your browser.

---

## Dependencies

| Package             | Purpose                          |
|----------------------|-----------------------------------|
| Flask                | Web framework / routing           |
| Flask-SQLAlchemy     | ORM for SQLite                    |
| Flask-CORS           | Cross-origin API access           |
| python-dotenv        | Loads `.env` configuration        |

---

## Database Setup

No manual setup required. On first run, `db.create_all()` inside the
application factory creates `lostlink.db` (SQLite) with the `items` and
`claims` tables automatically. To reset the database, simply delete
`lostlink.db` and restart the app.

### Schema

**items**

| Column       | Type      | Notes                          |
|--------------|-----------|---------------------------------|
| id           | Integer   | Primary key                     |
| type         | String    | `lost` \| `found`                |
| title        | String    |                                  |
| description  | Text      |                                  |
| category     | String    | from a fixed category list      |
| location     | String    | from a fixed campus location list |
| date         | Date      | when lost/found                 |
| owner_name   | String    | reporter's name                 |
| email        | String    | reporter's email                |
| phone        | String    | reporter's phone                |
| status       | String    | `open` \| `claimed` \| `returned` |
| created_at   | DateTime  |                                  |
| updated_at   | DateTime  |                                  |

**claims**

| Column        | Type      | Notes                             |
|---------------|-----------|------------------------------------|
| id            | Integer   | Primary key                        |
| item_id       | Integer   | FK → items.id                      |
| claimer_name  | String    |                                     |
| email         | String    |                                     |
| phone         | String    |                                     |
| reason        | Text      | why the claimer believes it's theirs |
| status        | String    | `pending` \| `approved` \| `rejected` |
| created_at    | DateTime  |                                     |
| updated_at    | DateTime  |                                     |

One item can have many claims (`items.claims`); deleting an item cascades
to delete its claims.

---

## Running in VS Code

1. Open the folder in VS Code.
2. Select the `venv` interpreter: `Ctrl+Shift+P` → **Python: Select Interpreter** → choose `venv`.
3. Open `run.py` and press **Run ▶** (or `F5`), or use the integrated terminal:
   ```bash
   python run.py
   ```
4. The Flask dev server starts on port `5000` with auto-reload enabled.

---

## REST API Endpoints

All API responses use this envelope:

```json
{ "success": true, "message": "…", "data": { }, "meta": { } }
{ "success": false, "error": "…" }
```

### Items

| Method | Endpoint                  | Description                          | Auth   |
|--------|----------------------------|---------------------------------------|--------|
| GET    | `/api/items`               | List items — search, filter, paginate | Public |
| POST   | `/api/items`                | Create a lost/found report            | Public |
| GET    | `/api/items/<id>`           | Get a single item (+ its claims)      | Public |
| PATCH  | `/api/items/<id>`           | Update an item (blocked if returned)  | Public |
| DELETE | `/api/items/<id>`           | Delete an item                        | Admin  |
| PATCH  | `/api/items/<id>/return`    | Mark item as returned                 | Admin  |

**Query params for `GET /api/items`:** `type`, `status`, `category`,
`location`, `search`, `page`, `page_size`.

### Claims

| Method | Endpoint                          | Description                       | Auth   |
|--------|-------------------------------------|-------------------------------------|--------|
| POST   | `/api/items/<item_id>/claims`      | Submit a claim on a found item     | Public |
| POST   | `/api/claims`                       | Submit a claim (`item_id` in body) | Public |
| GET    | `/api/claims`                       | List claims (filter by status/email) | Public |
| GET    | `/api/claims/<id>`                  | Get a single claim                 | Public |
| PATCH  | `/api/claims/<id>`                  | Set status: `approved` / `rejected`| Admin  |

### Admin

| Method | Endpoint                              | Description                        |
|--------|-----------------------------------------|--------------------------------------|
| POST   | `/api/admin/login`                     | Verify an admin key                  |
| GET    | `/api/admin/claims`                    | List all claims                      |
| PATCH  | `/api/admin/claims/<id>/approve`       | Approve claim (auto-rejects rest)    |
| PATCH  | `/api/admin/claims/<id>/reject`        | Reject claim                         |
| DELETE | `/api/admin/items/<id>`                | Delete a fake/invalid report         |
| PATCH  | `/api/admin/items/<id>/return`         | Mark item returned                   |
| GET    | `/api/admin/stats`                     | Full dashboard statistics            |

### Stats

| Method | Endpoint      | Description                     |
|--------|----------------|-----------------------------------|
| GET    | `/api/stats`   | Public totals for the homepage    |

Admin endpoints require header: `X-Admin-Key: <your admin key>`.

---

## Validation Rules

- **Required fields**: type, title, description, category, location,
  owner_name, email, phone (on create); claimer_name, email, phone, reason
  (on claim)
- **Email**: must match a standard email pattern
- **Phone**: must be a 10-digit mobile number
- **Category / Location**: must match one of the predefined lists
  (`app/utils/validators.py`)
- **Title**: 3–120 characters; **Description**: 10–2000 characters
- **Date**: must be `YYYY-MM-DD` if provided
- Empty or whitespace-only required fields are rejected with a 400 and the
  list of missing fields

---

## Business Logic

- **Only FOUND items can be claimed.** Claiming a LOST item returns 409.
- **Returned items cannot be edited or claimed.** Both return 409.
- **Duplicate reports are rejected**: same type + title + category +
  location + reporter email within 48 hours returns 409 with the existing
  item's id.
- **Duplicate pending claims are rejected**: the same person can't have two
  pending claims on the same item.
- **Claim approval auto-rejects the rest**: approving one claim on an item
  sets the item to `claimed` and automatically rejects every other
  `pending` claim on that item.
- **Claims can only be resolved once**: an already-approved or
  already-rejected claim cannot be changed again (409).
- **Invalid IDs** return 404 with a clear message, never a stack trace.
- All state transitions are enforced server-side in the service layer —
  the frontend has no special privileges the API doesn't also enforce.

---

## Error Handling

All errors are handled centrally in `app/__init__.py` via
`register_error_handlers`, backed by the `APIError` hierarchy in
`app/utils/errors.py`:

- `ValidationError` → 400
- `UnauthorizedError` → 401
- `NotFoundError` → 404
- `ConflictError` → 409
- Unhandled exceptions → 500, logged server-side, never exposed to the client

Every error response is JSON: `{ "success": false, "error": "…" }`.

---

## Future Scope

The following are intentionally **not implemented** in this version, but
are natural next steps:

- 📷 Image upload for item photos
- 🤖 AI-based image matching between lost and found reports
- 🔗 QR code generation for verified item handover
- 📧 Email notifications on claim status changes
- 🔐 College SSO / login integration for students and staff

---

## Tech Stack Summary

- **Backend**: Python, Flask, Flask-SQLAlchemy, Flask-CORS
- **Database**: SQLite (via SQLAlchemy ORM — no raw SQL)
- **Frontend**: HTML5, CSS3 (custom, no framework), vanilla JavaScript (fetch API)
