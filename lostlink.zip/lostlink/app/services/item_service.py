"""
Item service — all business logic for creating, querying, updating,
deleting and transitioning Items lives here, kept separate from the
route/controller layer.
"""
from datetime import datetime, timedelta

from sqlalchemy import or_

from app.extensions import db
from app.models.item import Item, ItemStatus, ItemType
from app.models.claim import Claim, ClaimStatus
from app.utils.errors import NotFoundError, ConflictError, ValidationError
from app.utils.validators import validate_item_payload

DUPLICATE_WINDOW_HOURS = 48


def get_item_or_404(item_id):
    item = Item.query.get(item_id)
    if not item:
        raise NotFoundError(f"Item with id {item_id} was not found.")
    return item


def _check_duplicate(cleaned):
    """
    Reject duplicate reports: same type + title + category + location + email
    reported again within the duplicate window while not yet returned.
    """
    cutoff = datetime.utcnow() - timedelta(hours=DUPLICATE_WINDOW_HOURS)
    existing = Item.query.filter(
        Item.type == cleaned["type"],
        Item.title.ilike(cleaned["title"]),
        Item.category == cleaned["category"],
        Item.location == cleaned["location"],
        Item.email == cleaned["email"],
        Item.status != ItemStatus.RETURNED,
        Item.created_at >= cutoff,
    ).first()
    if existing:
        raise ConflictError(
            "A duplicate report already exists for this item, reporter and location.",
            payload={"existing_item_id": existing.id},
        )


def create_item(data):
    cleaned = validate_item_payload(data, partial=False)
    _check_duplicate(cleaned)

    item = Item(
        type=cleaned["type"],
        title=cleaned["title"],
        description=cleaned["description"],
        category=cleaned["category"],
        location=cleaned["location"],
        date=cleaned.get("date") or datetime.utcnow().date(),
        owner_name=cleaned["owner_name"],
        email=cleaned["email"],
        phone=cleaned["phone"],
        status=ItemStatus.OPEN,
    )
    db.session.add(item)
    db.session.commit()
    return item


def list_items(args, default_page_size=12, max_page_size=50):
    query = Item.query

    item_type = args.get("type")
    if item_type:
        query = query.filter(Item.type == item_type.lower())

    status = args.get("status")
    if status:
        query = query.filter(Item.status == status.lower())

    category = args.get("category")
    if category:
        query = query.filter(Item.category == category)

    location = args.get("location")
    if location:
        query = query.filter(Item.location == location)

    search = args.get("search") or args.get("q")
    if search:
        like = f"%{search}%"
        query = query.filter(
            or_(
                Item.title.ilike(like),
                Item.description.ilike(like),
                Item.category.ilike(like),
                Item.location.ilike(like),
            )
        )

    query = query.order_by(Item.created_at.desc())

    try:
        page = max(int(args.get("page", 1)), 1)
    except (TypeError, ValueError):
        page = 1
    try:
        page_size = int(args.get("page_size", default_page_size))
    except (TypeError, ValueError):
        page_size = default_page_size
    page_size = max(1, min(page_size, max_page_size))

    total = query.count()
    items = query.offset((page - 1) * page_size).limit(page_size).all()

    meta = {
        "page": page,
        "page_size": page_size,
        "total": total,
        "total_pages": (total + page_size - 1) // page_size if page_size else 1,
    }
    return items, meta


def update_item(item_id, data):
    item = get_item_or_404(item_id)

    if item.status == ItemStatus.RETURNED:
        raise ConflictError("Returned items can no longer be edited.")

    cleaned = validate_item_payload(data, partial=True)
    for key, value in cleaned.items():
        setattr(item, key, value)

    db.session.commit()
    return item


def delete_item(item_id):
    item = get_item_or_404(item_id)
    db.session.delete(item)
    db.session.commit()


def mark_returned(item_id):
    item = get_item_or_404(item_id)
    if item.status == ItemStatus.RETURNED:
        raise ConflictError("Item is already marked as returned.")

    item.status = ItemStatus.RETURNED

    # Any still-pending claims on this item become moot once it's returned.
    for claim in item.claims.filter(Claim.status == ClaimStatus.PENDING):
        claim.status = ClaimStatus.REJECTED

    db.session.commit()
    return item
