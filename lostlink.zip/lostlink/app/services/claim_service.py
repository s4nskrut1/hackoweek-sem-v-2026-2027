"""
Claim service — business logic for submitting and resolving claims on
FOUND items, including the auto-reject-remaining-claims workflow.
"""
from app.extensions import db
from app.models.item import Item, ItemStatus, ItemType
from app.models.claim import Claim, ClaimStatus
from app.utils.errors import NotFoundError, ConflictError, ValidationError
from app.utils.validators import validate_claim_payload


def get_claim_or_404(claim_id):
    claim = Claim.query.get(claim_id)
    if not claim:
        raise NotFoundError(f"Claim with id {claim_id} was not found.")
    return claim


def create_claim(item_id, data):
    item = Item.query.get(item_id)
    if not item:
        raise NotFoundError(f"Item with id {item_id} was not found.")

    if item.type != ItemType.FOUND:
        raise ConflictError("Only items reported as FOUND can be claimed.")

    if item.status == ItemStatus.RETURNED:
        raise ConflictError("This item has already been returned and can no longer be claimed.")

    if item.status == ItemStatus.CLAIMED:
        raise ConflictError("This item already has an approved claim pending handover.")

    cleaned = validate_claim_payload(data)

    duplicate = Claim.query.filter(
        Claim.item_id == item.id,
        Claim.email == cleaned["email"],
        Claim.status == ClaimStatus.PENDING,
    ).first()
    if duplicate:
        raise ConflictError(
            "You already have a pending claim on this item.",
            payload={"existing_claim_id": duplicate.id},
        )

    claim = Claim(
        item_id=item.id,
        claimer_name=cleaned["claimer_name"],
        email=cleaned["email"],
        phone=cleaned["phone"],
        reason=cleaned["reason"],
        status=ClaimStatus.PENDING,
    )
    db.session.add(claim)
    db.session.commit()
    return claim


def list_claims(args):
    query = Claim.query
    status = args.get("status")
    if status:
        query = query.filter(Claim.status == status.lower())
    item_id = args.get("item_id")
    if item_id:
        query = query.filter(Claim.item_id == item_id)
    email = args.get("email")
    if email:
        query = query.filter(Claim.email == email.lower())
    return query.order_by(Claim.created_at.desc()).all()


def update_claim_status(claim_id, new_status):
    claim = get_claim_or_404(claim_id)

    if new_status not in ClaimStatus.ALL:
        raise ValidationError(f"Invalid status '{new_status}'. Must be one of: {', '.join(ClaimStatus.ALL)}")

    if claim.status != ClaimStatus.PENDING:
        raise ConflictError(f"Claim is already '{claim.status}' and cannot be changed again.")

    item = claim.item

    if new_status == ClaimStatus.APPROVED:
        if item.status == ItemStatus.RETURNED:
            raise ConflictError("Cannot approve a claim for an item that has already been returned.")

        claim.status = ClaimStatus.APPROVED
        item.status = ItemStatus.CLAIMED

        # Business rule: approving one claim auto-rejects all other pending claims.
        for other in item.claims.filter(Claim.id != claim.id, Claim.status == ClaimStatus.PENDING):
            other.status = ClaimStatus.REJECTED

    elif new_status == ClaimStatus.REJECTED:
        claim.status = ClaimStatus.REJECTED

    db.session.commit()
    return claim
