"""
Route decorators — currently just admin authentication.
"""
from functools import wraps

from flask import request, current_app

from app.utils.errors import UnauthorizedError


def admin_required(fn):
    """
    Protects a route with the simple ADMIN_KEY scheme described in the
    project spec. The admin client must send header: X-Admin-Key: <key>
    """

    @wraps(fn)
    def wrapper(*args, **kwargs):
        supplied_key = request.headers.get("X-Admin-Key", "")
        expected_key = current_app.config["ADMIN_KEY"]
        if not supplied_key or supplied_key != expected_key:
            raise UnauthorizedError("Missing or invalid admin key.")
        return fn(*args, **kwargs)

    return wrapper
