"""
Custom exception types used across the application.

Every business-logic or validation failure should raise an APIError (or a
subclass). The centralized error handler registered in app/__init__.py
converts these into consistent JSON responses, so route handlers never need
to build error JSON by hand and stack traces are never leaked to clients.
"""


class APIError(Exception):
    """Base class for all handled API errors."""

    status_code = 400

    def __init__(self, message, status_code=None, payload=None):
        super().__init__(message)
        self.message = message
        if status_code is not None:
            self.status_code = status_code
        self.payload = payload or {}

    def to_dict(self):
        body = dict(self.payload)
        body["success"] = False
        body["error"] = self.message
        return body


class ValidationError(APIError):
    """Raised when request payload fails validation. -> 400"""

    status_code = 400


class NotFoundError(APIError):
    """Raised when a requested resource does not exist. -> 404"""

    status_code = 404


class ConflictError(APIError):
    """Raised for state conflicts: duplicates, invalid transitions. -> 409"""

    status_code = 409


class UnauthorizedError(APIError):
    """Raised when admin authentication fails or is missing. -> 401"""

    status_code = 401
