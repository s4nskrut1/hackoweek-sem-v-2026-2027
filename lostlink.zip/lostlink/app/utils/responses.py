"""
Helpers that produce consistently-shaped JSON success responses.
Pairs with utils/errors.py, which handles the error side.
"""
from flask import jsonify


def success(data=None, message=None, status_code=200, meta=None):
    """Build a standard success envelope: {success, message, data, meta}."""
    body = {"success": True}
    if message is not None:
        body["message"] = message
    if data is not None:
        body["data"] = data
    if meta is not None:
        body["meta"] = meta
    return jsonify(body), status_code
