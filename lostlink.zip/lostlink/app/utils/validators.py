"""
Validation helpers and reference data (categories, locations) shared by
the service layer. Keeping these in one place ensures item and claim
payloads are validated consistently across every endpoint.
"""
import re
from datetime import date, datetime

from app.utils.errors import ValidationError

EMAIL_RE = re.compile(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")
PHONE_RE = re.compile(r"^[6-9]\d{9}$")  # 10-digit Indian mobile format

CATEGORIES = [
    "ID Card",
    "Wallet",
    "Keys",
    "Books",
    "Earphones",
    "Laptop",
    "Water Bottle",
    "Calculator",
    "Documents",
    "Electronics",
    "Bag",
    "Clothing",
    "Other",
]

LOCATIONS = [
    "Library",
    "Canteen",
    "Main Building",
    "Sports Complex",
    "Hostel Block A",
    "Hostel Block B",
    "Parking Lot",
    "Auditorium",
    "Lab Block",
    "Admin Office",
    "Playground",
    "Other",
]

ITEM_TYPES = ["lost", "found"]


def require_fields(data, fields):
    missing = [f for f in fields if not str(data.get(f, "")).strip()]
    if missing:
        raise ValidationError(
            f"Missing or empty required field(s): {', '.join(missing)}",
            payload={"fields": missing},
        )


def validate_email(value):
    if not EMAIL_RE.match(str(value).strip()):
        raise ValidationError("Invalid email address format.", payload={"field": "email"})
    return str(value).strip().lower()


def validate_phone(value):
    cleaned = re.sub(r"[\s\-()]", "", str(value))
    if not PHONE_RE.match(cleaned):
        raise ValidationError(
            "Invalid phone number. Expected a 10-digit mobile number.",
            payload={"field": "phone"},
        )
    return cleaned


def validate_category(value):
    if value not in CATEGORIES:
        raise ValidationError(
            f"Invalid category '{value}'. Allowed categories: {', '.join(CATEGORIES)}",
            payload={"field": "category", "allowed": CATEGORIES},
        )
    return value


def validate_location(value):
    if value not in LOCATIONS:
        raise ValidationError(
            f"Invalid location '{value}'. Allowed locations: {', '.join(LOCATIONS)}",
            payload={"field": "location", "allowed": LOCATIONS},
        )
    return value


def validate_item_type(value):
    if value not in ITEM_TYPES:
        raise ValidationError(
            f"Invalid type '{value}'. Must be one of: {', '.join(ITEM_TYPES)}",
            payload={"field": "type", "allowed": ITEM_TYPES},
        )
    return value


def validate_date(value):
    if value in (None, ""):
        return date.today()
    if isinstance(value, date):
        return value
    try:
        return datetime.strptime(str(value), "%Y-%m-%d").date()
    except ValueError:
        raise ValidationError(
            "Invalid date format. Expected YYYY-MM-DD.", payload={"field": "date"}
        )


def validate_text_length(value, field_name, min_len=1, max_len=2000):
    text = str(value).strip()
    if len(text) < min_len:
        raise ValidationError(f"'{field_name}' must not be empty.", payload={"field": field_name})
    if len(text) > max_len:
        raise ValidationError(
            f"'{field_name}' must be at most {max_len} characters.",
            payload={"field": field_name},
        )
    return text


def validate_item_payload(data, partial=False):
    """
    Validate and normalize an item creation/update payload.
    When partial=True (PATCH), only validate fields that are present.
    """
    required = ["type", "title", "description", "category", "location", "owner_name", "email", "phone"]
    if not partial:
        require_fields(data, required)

    cleaned = {}

    if "type" in data:
        cleaned["type"] = validate_item_type(str(data["type"]).strip().lower())
    if "title" in data:
        cleaned["title"] = validate_text_length(data["title"], "title", min_len=3, max_len=120)
    if "description" in data:
        cleaned["description"] = validate_text_length(
            data["description"], "description", min_len=10, max_len=2000
        )
    if "category" in data:
        cleaned["category"] = validate_category(str(data["category"]).strip())
    if "location" in data:
        cleaned["location"] = validate_location(str(data["location"]).strip())
    if "date" in data:
        cleaned["date"] = validate_date(data["date"])
    if "owner_name" in data:
        cleaned["owner_name"] = validate_text_length(
            data["owner_name"], "owner_name", min_len=2, max_len=100
        )
    if "email" in data:
        cleaned["email"] = validate_email(data["email"])
    if "phone" in data:
        cleaned["phone"] = validate_phone(data["phone"])

    return cleaned


def validate_claim_payload(data):
    required = ["claimer_name", "email", "phone", "reason"]
    require_fields(data, required)

    return {
        "claimer_name": validate_text_length(data["claimer_name"], "claimer_name", min_len=2, max_len=100),
        "email": validate_email(data["email"]),
        "phone": validate_phone(data["phone"]),
        "reason": validate_text_length(data["reason"], "reason", min_len=10, max_len=1000),
    }
