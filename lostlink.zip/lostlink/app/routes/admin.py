"""
Admin-only endpoints, protected by the X-Admin-Key header (see
utils/decorators.admin_required).

    POST   /api/admin/login                 verify an admin key
    GET    /api/admin/claims                list all claims (any status)
    PATCH  /api/admin/claims/<id>/approve   approve a claim
    PATCH  /api/admin/claims/<id>/reject    reject a claim
    DELETE /api/admin/items/<id>            delete a (fake) report
    PATCH  /api/admin/items/<id>/return     mark an item as returned
    GET    /api/admin/stats                 full statistics for dashboard
"""
from flask import Blueprint, request

from app.services import item_service, claim_service
from app.models.claim import Claim, ClaimStatus
from app.utils.responses import success
from app.utils.decorators import admin_required

admin_bp = Blueprint("admin", __name__, url_prefix="/api/admin")


@admin_bp.post("/login")
@admin_required
def login():
    # If admin_required didn't raise, the key is valid.
    return success(message="Admin authenticated successfully.")


@admin_bp.get("/claims")
@admin_required
def list_all_claims():
    claims = claim_service.list_claims(request.args)
    return success(data=[c.to_dict(include_item=True) for c in claims])


@admin_bp.patch("/claims/<int:claim_id>/approve")
@admin_required
def approve_claim(claim_id):
    claim = claim_service.update_claim_status(claim_id, ClaimStatus.APPROVED)
    return success(data=claim.to_dict(), message="Claim approved. Other pending claims auto-rejected.")


@admin_bp.patch("/claims/<int:claim_id>/reject")
@admin_required
def reject_claim(claim_id):
    claim = claim_service.update_claim_status(claim_id, ClaimStatus.REJECTED)
    return success(data=claim.to_dict(), message="Claim rejected.")


@admin_bp.delete("/items/<int:item_id>")
@admin_required
def delete_fake_report(item_id):
    item_service.delete_item(item_id)
    return success(message="Report deleted successfully.")


@admin_bp.patch("/items/<int:item_id>/return")
@admin_required
def mark_item_returned(item_id):
    item = item_service.mark_returned(item_id)
    return success(data=item.to_dict(), message="Item marked as returned.")


@admin_bp.get("/stats")
@admin_required
def admin_stats():
    from app.models.item import Item, ItemStatus
    total_pending_claims = Claim.query.filter_by(status=ClaimStatus.PENDING).count()
    total_items = Item.query.count()
    data = {
        "total_items": total_items,
        "open_items": Item.query.filter_by(status=ItemStatus.OPEN).count(),
        "claimed_items": Item.query.filter_by(status=ItemStatus.CLAIMED).count(),
        "returned_items": Item.query.filter_by(status=ItemStatus.RETURNED).count(),
        "total_claims": Claim.query.count(),
        "pending_claims": total_pending_claims,
        "approved_claims": Claim.query.filter_by(status=ClaimStatus.APPROVED).count(),
        "rejected_claims": Claim.query.filter_by(status=ClaimStatus.REJECTED).count(),
    }
    return success(data=data)
