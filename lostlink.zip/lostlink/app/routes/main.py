"""
Frontend routes — these only render templates that consume the REST API
via JavaScript (see static/js/). No business logic lives here.
"""
from flask import Blueprint, render_template

from app.utils.validators import CATEGORIES, LOCATIONS

main_bp = Blueprint("main", __name__)


@main_bp.get("/")
def home():
    return render_template("index.html")


@main_bp.get("/report")
def report():
    return render_template("report.html", categories=CATEGORIES, locations=LOCATIONS)


@main_bp.get("/browse")
def browse():
    return render_template("browse.html", categories=CATEGORIES, locations=LOCATIONS)


@main_bp.get("/item/<int:item_id>")
def item_detail(item_id):
    return render_template("item_detail.html", item_id=item_id)


@main_bp.get("/track")
def track_claim():
    return render_template("track_claim.html")


@main_bp.get("/admin")
def admin():
    return render_template("admin.html")
