"""
REST endpoints for Item resources.

    GET    /api/items          list + search + filter + paginate
    POST   /api/items          create a lost/found report
    GET    /api/items/<id>     retrieve a single item
    PATCH  /api/items/<id>     update an item (not allowed once returned)
    DELETE /api/items/<id>     delete an item (admin only)
"""
from flask import Blueprint, request

from app.services import item_service
from app.utils.responses import success
from app.utils.decorators import admin_required

items_bp = Blueprint("items", __name__, url_prefix="/api/items")


@items_bp.get("")
def list_items():
    from flask import current_app

    items, meta = item_service.list_items(
        request.args,
        default_page_size=current_app.config["DEFAULT_PAGE_SIZE"],
        max_page_size=current_app.config["MAX_PAGE_SIZE"],
    )
    return success(data=[i.to_dict() for i in items], meta=meta)


@items_bp.post("")
def create_item():
    data = request.get_json(silent=True) or {}
    item = item_service.create_item(data)
    return success(data=item.to_dict(), message="Item reported successfully.", status_code=201)


@items_bp.get("/<int:item_id>")
def get_item(item_id):
    item = item_service.get_item_or_404(item_id)
    return success(data=item.to_dict(include_claims=True))


@items_bp.patch("/<int:item_id>")
def patch_item(item_id):
    data = request.get_json(silent=True) or {}
    item = item_service.update_item(item_id, data)
    return success(data=item.to_dict(), message="Item updated successfully.")


@items_bp.delete("/<int:item_id>")
@admin_required
def delete_item(item_id):
    item_service.delete_item(item_id)
    return success(message="Item deleted successfully.")


@items_bp.patch("/<int:item_id>/return")
@admin_required
def return_item(item_id):
    item = item_service.mark_returned(item_id)
    return success(data=item.to_dict(), message="Item marked as returned.")
