"""
REST endpoints for Claim resources.

    POST   /api/items/<item_id>/claims   submit a claim on a found item
    GET    /api/claims/<id>              retrieve a single claim
    GET    /api/claims                   list claims (filter by email/status)
    PATCH  /api/claims/<id>              change claim status (admin only)
"""
from flask import Blueprint, request

from app.services import claim_service
from app.utils.responses import success
from app.utils.decorators import admin_required
from app.utils.errors import ValidationError

claims_bp = Blueprint("claims", __name__, url_prefix="/api")


@claims_bp.post("/items/<int:item_id>/claims")
def create_claim(item_id):
    data = request.get_json(silent=True) or {}
    claim = claim_service.create_claim(item_id, data)
    return success(data=claim.to_dict(), message="Claim submitted successfully.", status_code=201)


@claims_bp.post("/claims")
def create_claim_flat():
    """Alternate flat endpoint: POST /api/claims with item_id in the body."""
    data = request.get_json(silent=True) or {}
    item_id = data.get("item_id")
    if not item_id:
        raise ValidationError("Field 'item_id' is required.")
    claim = claim_service.create_claim(int(item_id), data)
    return success(data=claim.to_dict(), message="Claim submitted successfully.", status_code=201)


@claims_bp.get("/claims")

def list_claims():
    claims = claim_service.list_claims(request.args)
    return success(data=[c.to_dict(include_item=True) for c in claims])


@claims_bp.get("/claims/<int:claim_id>")
def get_claim(claim_id):
    claim = claim_service.get_claim_or_404(claim_id)
    return success(data=claim.to_dict(include_item=True))


@claims_bp.patch("/claims/<int:claim_id>")
@admin_required
def patch_claim(claim_id):
    data = request.get_json(silent=True) or {}
    new_status = str(data.get("status", "")).strip().lower()
    if not new_status:
        raise ValidationError("Field 'status' is required (approved | rejected).")
    claim = claim_service.update_claim_status(claim_id, new_status)
    return success(data=claim.to_dict(), message=f"Claim {new_status} successfully.")
