"""
GET /api/stats — public statistics used by the homepage hero/stats section.
"""
from flask import Blueprint

from app.extensions import db
from app.models.item import Item, ItemType, ItemStatus
from app.models.claim import Claim, ClaimStatus
from app.utils.responses import success

stats_bp = Blueprint("stats", __name__, url_prefix="/api/stats")


@stats_bp.get("")
def get_stats():
    total_reports = Item.query.count()
    total_lost = Item.query.filter_by(type=ItemType.LOST).count()
    total_found = Item.query.filter_by(type=ItemType.FOUND).count()
    items_returned = Item.query.filter_by(status=ItemStatus.RETURNED).count()
    pending_claims = Claim.query.filter_by(status=ClaimStatus.PENDING).count()
    approved_claims = Claim.query.filter_by(status=ClaimStatus.APPROVED).count()

    recovery_rate = round((items_returned / total_reports) * 100, 1) if total_reports else 0.0

    data = {
        "total_reports": total_reports,
        "total_lost": total_lost,
        "total_found": total_found,
        "items_returned": items_returned,
        "pending_claims": pending_claims,
        "approved_claims": approved_claims,
        "recovery_rate": recovery_rate,
    }
    return success(data=data)
