"""
Application factory. Wires together config, extensions, blueprints and
centralized error handling. Using the factory pattern keeps the app
testable and avoids import-time side effects.
"""
import os

from flask import Flask

from config import config_by_name
from app.extensions import db, cors
from app.utils.errors import APIError


def create_app(config_name=None):
    app = Flask(__name__)

    config_name = config_name or os.environ.get("FLASK_ENV", "development")
    app.config.from_object(config_by_name.get(config_name, config_by_name["development"]))

    # --- Extensions -------------------------------------------------
    db.init_app(app)
    cors.init_app(app, resources={r"/api/*": {"origins": "*"}})

    # --- Blueprints ---------------------------------------------------
    from app.routes.main import main_bp
    from app.routes.items import items_bp
    from app.routes.claims import claims_bp
    from app.routes.stats import stats_bp
    from app.routes.admin import admin_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(items_bp)
    app.register_blueprint(claims_bp)
    app.register_blueprint(stats_bp)
    app.register_blueprint(admin_bp)

    register_error_handlers(app)

    with app.app_context():
        db.create_all()

    return app


def register_error_handlers(app):
    """
    Centralized error handling. Every handled error returns a clean JSON
    body — no stack traces are ever exposed to the client.
    """

    @app.errorhandler(APIError)
    def handle_api_error(err):
        return err.to_dict(), err.status_code

    @app.errorhandler(404)
    def handle_404(err):
        return {"success": False, "error": "The requested resource was not found."}, 404

    @app.errorhandler(405)
    def handle_405(err):
        return {"success": False, "error": "This HTTP method is not allowed on this endpoint."}, 405

    @app.errorhandler(400)
    def handle_400(err):
        return {"success": False, "error": "The request could not be understood by the server."}, 400

    @app.errorhandler(500)
    def handle_500(err):
        app.logger.exception("Unhandled server error")
        return {"success": False, "error": "An unexpected server error occurred. Please try again later."}, 500
