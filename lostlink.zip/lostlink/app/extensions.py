"""
Central place for Flask extension instances.
Instantiated here (unbound) and initialized inside the application factory
to avoid circular imports across the models/routes/services layers.
"""
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS

db = SQLAlchemy()
cors = CORS()
