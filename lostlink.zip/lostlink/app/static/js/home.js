/* home.js — populates the stats strip and recent-items grid on the homepage. */

function renderTagCard(item) {
  const typeClass = item.type === "lost" ? "badge-lost" : "badge-found";
  return `
    <div class="tag-card" onclick="window.location.href='/item/${item.id}'">
      <div class="tag-card-top">
        <span class="badge ${typeClass}">${item.type}</span>
        <span class="badge ${statusBadgeClass(item.status)}">${item.status}</span>
      </div>
      <h3>${escapeHtml(item.title)}</h3>
      <div class="meta">
        <span>📍 ${escapeHtml(item.location)}</span>
        <span>🏷️ ${escapeHtml(item.category)}</span>
        <span>📅 ${formatDate(item.date)}</span>
      </div>
      <p class="desc">${escapeHtml(item.description)}</p>
      <div class="tag-card-footer">
        <span class="id-chip">#${String(item.id).padStart(4, "0")}</span>
        <span class="btn btn-ghost btn-sm">View →</span>
      </div>
    </div>`;
}

async function loadStats() {
  try {
    const { data } = await api.getStats();
    document.getElementById("stat-total").textContent = data.total_reports;
    document.getElementById("stat-returned").textContent = data.items_returned;
    document.getElementById("stat-pending").textContent = data.pending_claims;
    document.getElementById("stat-rate").textContent = `${data.recovery_rate}%`;
  } catch (e) {
    console.error(e);
  }
}

async function loadRecent() {
  const container = document.getElementById("recent-items");
  try {
    const { data } = await api.listItems({ page: 1, page_size: 6 });
    if (!data.length) {
      container.innerHTML = `<div class="empty-state" style="grid-column:1/-1;"><h3>No reports yet</h3><p>Be the first to report a lost or found item.</p></div>`;
      return;
    }
    container.innerHTML = data.map(renderTagCard).join("");
  } catch (e) {
    container.innerHTML = `<p>Could not load recent reports right now.</p>`;
  }
}

loadStats();
loadRecent();
