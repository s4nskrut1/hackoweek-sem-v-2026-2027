/* item_detail.js — renders a single item and its claim form/state on /item/<id> */

function claimFormHtml(item) {
  return `
    <div class="detail-card">
      <h1 style="font-size:20px;">Submit a claim</h1>
      <p>Tell us how you know this belongs to you. Campus staff review every claim before approving it.</p>
      <div id="claim-msg" class="form-msg"></div>
      <form id="claim-form">
        <div class="field"><label for="c-name">Your name</label><input id="c-name" required></div>
        <div class="field"><label for="c-phone">Phone number</label><input id="c-phone" required></div>
        <div class="field"><label for="c-email">Email address</label><input id="c-email" type="email" required></div>
        <div class="field"><label for="c-reason">Why is this yours?</label><textarea id="c-reason" placeholder="Describe a unique detail — sticker, engraving, contents…" required></textarea></div>
        <button class="btn btn-accent btn-block" id="claim-submit" type="submit">Submit claim</button>
      </form>
    </div>`;
}

function nonClaimableNotice(item) {
  let reason = "";
  if (item.type === "lost") reason = "Only items reported as FOUND can be claimed.";
  else if (item.status === "returned") reason = "This item has already been returned to its owner.";
  else if (item.status === "claimed") reason = "This item already has an approved claim awaiting handover.";
  return `<div class="detail-card"><h1 style="font-size:20px;">Claims closed</h1><p>${reason}</p></div>`;
}

async function loadItem() {
  const root = document.getElementById("detail-root");
  try {
    const { data: item } = await api.getItem(ITEM_ID);
    const typeClass = item.type === "lost" ? "badge-lost" : "badge-found";

    root.innerHTML = `
      <div class="detail-wrap">
        <div class="detail-card">
          <div class="tag-card-top" style="margin-bottom:14px;">
            <span class="badge ${typeClass}">${item.type}</span>
            <span class="badge ${statusBadgeClass(item.status)}">${item.status}</span>
          </div>
          <h1>${escapeHtml(item.title)}</h1>
          <p>${escapeHtml(item.description)}</p>
          <div class="detail-meta-grid">
            <div><div class="item-label">Category</div><div class="item-value">${escapeHtml(item.category)}</div></div>
            <div><div class="item-label">Location</div><div class="item-value">${escapeHtml(item.location)}</div></div>
            <div><div class="item-label">Date</div><div class="item-value">${formatDate(item.date)}</div></div>
            <div><div class="item-label">Reference ID</div><div class="item-value">#${String(item.id).padStart(4, "0")}</div></div>
            <div><div class="item-label">Reported by</div><div class="item-value">${escapeHtml(item.owner_name)}</div></div>
            <div><div class="item-label">Contact</div><div class="item-value">${escapeHtml(item.phone)}</div></div>
          </div>
        </div>
        <div id="claim-area">${item.claimable ? claimFormHtml(item) : nonClaimableNotice(item)}</div>
      </div>`;

    if (item.claimable) {
      document.getElementById("claim-form").addEventListener("submit", async (e) => {
        e.preventDefault();
        const btn = document.getElementById("claim-submit");
        const msg = document.getElementById("claim-msg");
        const payload = {
          claimer_name: document.getElementById("c-name").value.trim(),
          phone: document.getElementById("c-phone").value.trim(),
          email: document.getElementById("c-email").value.trim(),
          reason: document.getElementById("c-reason").value.trim(),
        };
        btn.disabled = true;
        btn.innerHTML = `<span class="spinner"></span> Submitting…`;
        try {
          const { data } = await api.createClaim(ITEM_ID, payload);
          msg.textContent = `Claim submitted! Your claim ID is #${String(data.id).padStart(4, "0")}. Track its status anytime.`;
          msg.className = "form-msg show success";
          showToast("Claim submitted successfully", "success");
          document.getElementById("claim-form").reset();
        } catch (err) {
          msg.textContent = err.message || "Could not submit claim.";
          msg.className = "form-msg show error";
          showToast(err.message || "Claim failed", "error");
        } finally {
          btn.disabled = false;
          btn.textContent = "Submit claim";
        }
      });
    }
  } catch (err) {
    root.innerHTML = `<div class="empty-state"><h3>Item not found</h3><p>${err.message || "This report may have been removed."}</p></div>`;
  }
}

loadItem();
