/* report.js — handles the lost/found report form on /report */

let currentType = "lost";

function setType(type) {
  currentType = type;
  document.getElementById("type").value = type;
  const lostBtn = document.getElementById("toggle-lost");
  const foundBtn = document.getElementById("toggle-found");
  lostBtn.classList.toggle("active-lost", type === "lost");
  foundBtn.classList.toggle("active-found", type === "found");
  document.getElementById("owner-label").textContent = type === "lost" ? "Your name" : "Your name (finder)";
  document.getElementById("submit-btn").textContent = type === "lost" ? "Submit lost report" : "Submit found report";
}

function initFromQuery() {
  const params = new URLSearchParams(window.location.search);
  const t = params.get("type");
  setType(t === "found" ? "found" : "lost");
  const d = document.getElementById("date");
  d.value = new Date().toISOString().slice(0, 10);
}

function showFormMsg(msg, type) {
  const el = document.getElementById("form-msg");
  el.textContent = msg;
  el.className = `form-msg show ${type}`;
}

document.getElementById("report-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const btn = document.getElementById("submit-btn");
  const payload = {
    type: currentType,
    title: document.getElementById("title").value.trim(),
    category: document.getElementById("category").value,
    location: document.getElementById("location").value,
    date: document.getElementById("date").value,
    description: document.getElementById("description").value.trim(),
    owner_name: document.getElementById("owner_name").value.trim(),
    phone: document.getElementById("phone").value.trim(),
    email: document.getElementById("email").value.trim(),
  };

  btn.disabled = true;
  btn.innerHTML = `<span class="spinner"></span> Submitting…`;

  try {
    const { data } = await api.createItem(payload);
    showFormMsg(`Report submitted! Your reference ID is #${String(data.id).padStart(4, "0")}.`, "success");
    showToast("Report submitted successfully", "success");
    document.getElementById("report-form").reset();
    initFromQuery();
    setTimeout(() => { window.location.href = `/item/${data.id}`; }, 1200);
  } catch (err) {
    showFormMsg(err.message || "Something went wrong. Please try again.", "error");
    showToast(err.message || "Submission failed", "error");
  } finally {
    btn.disabled = false;
    btn.textContent = currentType === "lost" ? "Submit lost report" : "Submit found report";
  }
});

initFromQuery();
