/* track.js — looks up a single claim by ID on /track */

document.getElementById("track-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const id = document.getElementById("claim-id").value.trim();
  const result = document.getElementById("track-result");
  result.innerHTML = "<p>Looking up claim…</p>";

  try {
    const { data: claim } = await api.getClaim(id);
    result.innerHTML = `
      <div class="detail-card">
        <div class="tag-card-top">
          <span class="id-chip">Claim #${String(claim.id).padStart(4, "0")}</span>
          <span class="badge ${statusBadgeClass(claim.status)}">${claim.status}</span>
        </div>
        <h3 style="margin-top:10px;">${escapeHtml(claim.item ? claim.item.title : "Item")}</h3>
        <p><strong>Claimed by:</strong> ${escapeHtml(claim.claimer_name)}</p>
        <p><strong>Reason given:</strong> ${escapeHtml(claim.reason)}</p>
        <p><strong>Submitted:</strong> ${formatDate(claim.created_at)}</p>
        ${claim.item ? `<a href="/item/${claim.item.id}" class="btn btn-outline btn-sm">View item →</a>` : ""}
      </div>`;
  } catch (err) {
    result.innerHTML = `<div class="empty-state"><h3>Claim not found</h3><p>${err.message || "Double-check the claim ID and try again."}</p></div>`;
  }
});
