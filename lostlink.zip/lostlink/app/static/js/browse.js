/* browse.js — search, filter and paginate reports on /browse */

const state = { type: "", status: "", category: "", location: "", search: "", page: 1, page_size: 9 };

function renderCard(item) {
  const typeClass = item.type === "lost" ? "badge-lost" : "badge-found";
  return `
    <div class="tag-card" onclick="window.location.href='/item/${item.id}'">
      <div class="tag-card-top">
        <span class="badge ${typeClass}">${item.type}</span>
        <span class="badge ${statusBadgeClass(item.status)}">${item.status}</span>
      </div>
      <h3>${escapeHtml(item.title)}</h3>
      <div class="meta">
        <span>📍 ${escapeHtml(item.location)}</span>
        <span>🏷️ ${escapeHtml(item.category)}</span>
        <span>📅 ${formatDate(item.date)}</span>
      </div>
      <p class="desc">${escapeHtml(item.description)}</p>
      <div class="tag-card-footer">
        <span class="id-chip">#${String(item.id).padStart(4, "0")}</span>
        <span class="btn btn-ghost btn-sm">View →</span>
      </div>
    </div>`;
}

function renderPagination(meta) {
  const el = document.getElementById("pagination");
  if (meta.total_pages <= 1) { el.innerHTML = ""; return; }
  let html = `<button ${meta.page <= 1 ? "disabled" : ""} onclick="goToPage(${meta.page - 1})">‹</button>`;
  for (let p = 1; p <= meta.total_pages; p++) {
    html += `<button class="${p === meta.page ? "active" : ""}" onclick="goToPage(${p})">${p}</button>`;
  }
  html += `<button ${meta.page >= meta.total_pages ? "disabled" : ""} onclick="goToPage(${meta.page + 1})">›</button>`;
  el.innerHTML = html;
}

function goToPage(p) {
  state.page = p;
  loadResults();
  window.scrollTo({ top: 300, behavior: "smooth" });
}

async function loadResults() {
  const grid = document.getElementById("results-grid");
  grid.innerHTML = "<p>Loading reports…</p>";
  try {
    const { data, meta } = await api.listItems(state);
    if (!data.length) {
      grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1;">
        <h3>No matching reports</h3><p>Try adjusting your search or filters.</p></div>`;
      document.getElementById("pagination").innerHTML = "";
      return;
    }
    grid.innerHTML = data.map(renderCard).join("");
    renderPagination(meta);
  } catch (e) {
    grid.innerHTML = `<p>Could not load reports right now.</p>`;
  }
}

function applyFilters() {
  state.search = document.getElementById("f-search").value.trim();
  state.category = document.getElementById("f-category").value;
  state.location = document.getElementById("f-location").value;
  state.page = 1;
  loadResults();
}

document.getElementById("f-search").addEventListener("keydown", (e) => {
  if (e.key === "Enter") applyFilters();
});

document.querySelectorAll("#type-pills .pill").forEach((pill) => {
  pill.addEventListener("click", () => {
    document.querySelectorAll("#type-pills .pill").forEach((p) => p.classList.remove("active"));
    pill.classList.add("active");
    state.type = pill.dataset.type;
    state.page = 1;
    loadResults();
  });
});

document.querySelectorAll("#status-pills .pill").forEach((pill) => {
  pill.addEventListener("click", () => {
    document.querySelectorAll("#status-pills .pill").forEach((p) => p.classList.remove("active"));
    pill.classList.add("active");
    state.status = pill.dataset.status;
    state.page = 1;
    loadResults();
  });
});

// Support deep-linking, e.g. /browse?type=found
(function initFromQuery() {
  const params = new URLSearchParams(window.location.search);
  if (params.get("type")) {
    state.type = params.get("type");
    document.querySelectorAll("#type-pills .pill").forEach((p) => {
      p.classList.toggle("active", p.dataset.type === state.type);
    });
  }
})();

loadResults();
