/*
 * api.js — thin fetch wrapper around the LostLink REST API.
 * Every page includes this file first so pages share one consistent
 * way of talking to the backend and showing toasts/errors.
 */

const API_BASE = "/api";

function getAdminKey() {
  return sessionStorage.getItem("lostlink_admin_key") || "";
}

function setAdminKey(key) {
  sessionStorage.setItem("lostlink_admin_key", key);
}

function clearAdminKey() {
  sessionStorage.removeItem("lostlink_admin_key");
}

async function apiRequest(path, { method = "GET", body = null, admin = false } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (admin) headers["X-Admin-Key"] = getAdminKey();

  let res;
  try {
    res = await fetch(`${API_BASE}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch (networkErr) {
    throw { message: "Could not reach the server. Please check your connection.", status: 0 };
  }

  let json = null;
  try {
    json = await res.json();
  } catch (e) {
    json = null;
  }

  if (!res.ok) {
    const message = (json && json.error) || `Request failed with status ${res.status}`;
    throw { message, status: res.status, payload: json };
  }
  return json;
}

const api = {
  listItems: (params = {}) => {
    const qs = new URLSearchParams(
      Object.entries(params).filter(([, v]) => v !== "" && v !== null && v !== undefined)
    ).toString();
    return apiRequest(`/items${qs ? `?${qs}` : ""}`);
  },
  getItem: (id) => apiRequest(`/items/${id}`),
  createItem: (data) => apiRequest("/items", { method: "POST", body: data }),
  updateItem: (id, data) => apiRequest(`/items/${id}`, { method: "PATCH", body: data }),
  deleteItem: (id) => apiRequest(`/items/${id}`, { method: "DELETE", admin: true }),
  returnItem: (id) => apiRequest(`/items/${id}/return`, { method: "PATCH", admin: true }),

  createClaim: (itemId, data) => apiRequest(`/items/${itemId}/claims`, { method: "POST", body: data }),
  getClaim: (id) => apiRequest(`/claims/${id}`),
  listClaims: (params = {}) => {
    const qs = new URLSearchParams(
      Object.entries(params).filter(([, v]) => v !== "" && v !== null && v !== undefined)
    ).toString();
    return apiRequest(`/claims${qs ? `?${qs}` : ""}`);
  },

  getStats: () => apiRequest("/stats"),

  adminLogin: (key) =>
    fetch(`${API_BASE}/admin/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Admin-Key": key },
    }).then(async (res) => {
      const json = await res.json();
      if (!res.ok) throw { message: json.error || "Invalid admin key.", status: res.status };
      return json;
    }),
  adminListClaims: (params = {}) => {
    const qs = new URLSearchParams(
      Object.entries(params).filter(([, v]) => v !== "" && v !== null && v !== undefined)
    ).toString();
    return apiRequest(`/admin/claims${qs ? `?${qs}` : ""}`, { admin: true });
  },
  adminApproveClaim: (id) => apiRequest(`/admin/claims/${id}/approve`, { method: "PATCH", admin: true }),
  adminRejectClaim: (id) => apiRequest(`/admin/claims/${id}/reject`, { method: "PATCH", admin: true }),
  adminDeleteItem: (id) => apiRequest(`/admin/items/${id}`, { method: "DELETE", admin: true }),
  adminReturnItem: (id) => apiRequest(`/admin/items/${id}/return`, { method: "PATCH", admin: true }),
  adminStats: () => apiRequest("/admin/stats", { admin: true }),
};

/* ---------------------------------------------------------------------
   Toast helper — used across every page for success/error feedback.
   --------------------------------------------------------------------- */
function showToast(message, type = "success") {
  let toast = document.getElementById("global-toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "global-toast";
    toast.className = "toast";
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.className = `toast show ${type}`;
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.remove("show"), 3500);
}

function formatDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

function statusBadgeClass(status) {
  return `badge-${status}`;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}
