/* admin.js — login + dashboard (pending claims, all reports, all claims) on /admin */

let currentView = "claims";

function showLoginMsg(msg, type) {
  const el = document.getElementById("login-msg");
  el.textContent = msg;
  el.className = `form-msg show ${type}`;
}

async function tryAutoLogin() {
  if (getAdminKey()) {
    try {
      await api.adminLogin(getAdminKey());
      enterDashboard();
      return;
    } catch (e) {
      clearAdminKey();
    }
  }
}

document.getElementById("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const key = document.getElementById("admin-key").value.trim();
  try {
    await api.adminLogin(key);
    setAdminKey(key);
    enterDashboard();
  } catch (err) {
    showLoginMsg(err.message || "Invalid admin key.", "error");
  }
});

function adminLogout() {
  clearAdminKey();
  document.getElementById("dashboard-view").style.display = "none";
  document.getElementById("login-view").style.display = "block";
}

function enterDashboard() {
  document.getElementById("login-view").style.display = "none";
  document.getElementById("dashboard-view").style.display = "block";
  loadAdminStats();
  switchView("claims");
}

async function loadAdminStats() {
  try {
    const { data } = await api.adminStats();
    document.getElementById("admin-stats").innerHTML = `
      <div class="admin-stat-box"><div class="num">${data.total_items}</div><div class="lbl">Total Reports</div></div>
      <div class="admin-stat-box"><div class="num">${data.returned_items}</div><div class="lbl">Returned</div></div>
      <div class="admin-stat-box"><div class="num">${data.pending_claims}</div><div class="lbl">Pending Claims</div></div>
      <div class="admin-stat-box"><div class="num">${data.approved_claims}</div><div class="lbl">Approved Claims</div></div>`;
  } catch (e) {
    showToast(e.message || "Could not load stats", "error");
  }
}

function switchView(view) {
  currentView = view;
  document.querySelectorAll(".admin-sidebar button").forEach((b) => {
    b.classList.toggle("active", b.dataset.view === view);
  });
  if (view === "claims") renderPendingClaims();
  if (view === "items") renderAllItems();
  if (view === "all-claims") renderAllClaims();
}

async function renderPendingClaims() {
  const main = document.getElementById("admin-main");
  main.innerHTML = "<p>Loading pending claims…</p>";
  try {
    const { data } = await api.adminListClaims({ status: "pending" });
    if (!data.length) {
      main.innerHTML = `<div class="empty-state"><h3>No pending claims</h3><p>You're all caught up.</p></div>`;
      return;
    }
    main.innerHTML = `
      <table class="admin-table">
        <thead><tr><th>Claim</th><th>Item</th><th>Claimer</th><th>Reason</th><th>Actions</th></tr></thead>
        <tbody>${data.map((c) => `
          <tr>
            <td class="id-chip">#${String(c.id).padStart(4, "0")}</td>
            <td>${c.item ? escapeHtml(c.item.title) : "—"}</td>
            <td>${escapeHtml(c.claimer_name)}<br><span style="color:var(--ink-soft); font-size:12px;">${escapeHtml(c.email)}</span></td>
            <td style="max-width:260px;">${escapeHtml(c.reason)}</td>
            <td class="row-actions">
              <button class="btn btn-primary btn-sm" onclick="approveClaim(${c.id})">Approve</button>
              <button class="btn btn-danger btn-sm" onclick="rejectClaim(${c.id})">Reject</button>
            </td>
          </tr>`).join("")}
        </tbody>
      </table>`;
  } catch (e) {
    main.innerHTML = `<p>Could not load claims: ${e.message}</p>`;
  }
}

async function approveClaim(id) {
  try {
    await api.adminApproveClaim(id);
    showToast("Claim approved. Other pending claims auto-rejected.", "success");
    renderPendingClaims();
    loadAdminStats();
  } catch (e) {
    showToast(e.message || "Could not approve claim", "error");
  }
}

async function rejectClaim(id) {
  try {
    await api.adminRejectClaim(id);
    showToast("Claim rejected.", "success");
    renderPendingClaims();
    loadAdminStats();
  } catch (e) {
    showToast(e.message || "Could not reject claim", "error");
  }
}

async function renderAllItems() {
  const main = document.getElementById("admin-main");
  main.innerHTML = "<p>Loading reports…</p>";
  try {
    const { data } = await api.listItems({ page_size: 50 });
    if (!data.length) {
      main.innerHTML = `<div class="empty-state"><h3>No reports yet</h3></div>`;
      return;
    }
    main.innerHTML = `
      <table class="admin-table">
        <thead><tr><th>ID</th><th>Title</th><th>Type</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>${data.map((i) => `
          <tr>
            <td class="id-chip">#${String(i.id).padStart(4, "0")}</td>
            <td><a href="/item/${i.id}" target="_blank">${escapeHtml(i.title)}</a></td>
            <td><span class="badge ${i.type === "lost" ? "badge-lost" : "badge-found"}">${i.type}</span></td>
            <td><span class="badge ${statusBadgeClass(i.status)}">${i.status}</span></td>
            <td class="row-actions">
              ${i.status !== "returned" ? `<button class="btn btn-outline btn-sm" onclick="markReturned(${i.id})">Mark returned</button>` : ""}
              <button class="btn btn-danger btn-sm" onclick="deleteReport(${i.id})">Delete</button>
            </td>
          </tr>`).join("")}
        </tbody>
      </table>`;
  } catch (e) {
    main.innerHTML = `<p>Could not load reports: ${e.message}</p>`;
  }
}

async function markReturned(id) {
  try {
    await api.adminReturnItem(id);
    showToast("Item marked as returned.", "success");
    renderAllItems();
    loadAdminStats();
  } catch (e) {
    showToast(e.message || "Could not update item", "error");
  }
}

async function deleteReport(id) {
  if (!confirm("Delete this report permanently? This cannot be undone.")) return;
  try {
    await api.adminDeleteItem(id);
    showToast("Report deleted.", "success");
    renderAllItems();
    loadAdminStats();
  } catch (e) {
    showToast(e.message || "Could not delete report", "error");
  }
}

async function renderAllClaims() {
  const main = document.getElementById("admin-main");
  main.innerHTML = "<p>Loading claims…</p>";
  try {
    const { data } = await api.adminListClaims();
    if (!data.length) {
      main.innerHTML = `<div class="empty-state"><h3>No claims yet</h3></div>`;
      return;
    }
    main.innerHTML = `
      <table class="admin-table">
        <thead><tr><th>ID</th><th>Item</th><th>Claimer</th><th>Status</th><th>Submitted</th></tr></thead>
        <tbody>${data.map((c) => `
          <tr>
            <td class="id-chip">#${String(c.id).padStart(4, "0")}</td>
            <td>${c.item ? `<a href="/item/${c.item.id}" target="_blank">${escapeHtml(c.item.title)}</a>` : "—"}</td>
            <td>${escapeHtml(c.claimer_name)}</td>
            <td><span class="badge ${statusBadgeClass(c.status)}">${c.status}</span></td>
            <td>${formatDate(c.created_at)}</td>
          </tr>`).join("")}
        </tbody>
      </table>`;
  } catch (e) {
    main.innerHTML = `<p>Could not load claims: ${e.message}</p>`;
  }
}

tryAutoLogin();
