"""
Item model — represents a Lost or Found report submitted by a student.
"""
from datetime import datetime, date
from app.extensions import db


class ItemType:
    LOST = "lost"
    FOUND = "found"
    ALL = [LOST, FOUND]


class ItemStatus:
    OPEN = "open"          # actively lost / actively available for claim
    CLAIMED = "claimed"     # a claim has been approved, awaiting handover
    RETURNED = "returned"   # closed — item handed back to owner
    ALL = [OPEN, CLAIMED, RETURNED]


class Item(db.Model):
    __tablename__ = "items"

    id = db.Column(db.Integer, primary_key=True)

    type = db.Column(db.String(10), nullable=False)          # lost | found
    title = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), nullable=False)
    location = db.Column(db.String(80), nullable=False)
    date = db.Column(db.Date, nullable=False, default=date.today)

    owner_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(20), nullable=False)

    status = db.Column(db.String(20), nullable=False, default=ItemStatus.OPEN)

    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    claims = db.relationship(
        "Claim",
        backref="item",
        lazy="dynamic",
        cascade="all, delete-orphan",
    )

    def to_dict(self, include_claims=False):
        data = {
            "id": self.id,
            "type": self.type,
            "title": self.title,
            "description": self.description,
            "category": self.category,
            "location": self.location,
            "date": self.date.isoformat() if self.date else None,
            "owner_name": self.owner_name,
            "email": self.email,
            "phone": self.phone,
            "status": self.status,
            "claimable": self.type == ItemType.FOUND and self.status == ItemStatus.OPEN,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
        if include_claims:
            data["claims"] = [c.to_dict() for c in self.claims]
        return data

    def __repr__(self):
        return f"<Item {self.id} {self.type} '{self.title}' status={self.status}>"
