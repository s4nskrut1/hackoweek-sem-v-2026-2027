"""
Claim model — represents a student's claim on a FOUND item.
"""
from datetime import datetime
from app.extensions import db


class ClaimStatus:
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    ALL = [PENDING, APPROVED, REJECTED]


class Claim(db.Model):
    __tablename__ = "claims"

    id = db.Column(db.Integer, primary_key=True)
    item_id = db.Column(db.Integer, db.ForeignKey("items.id"), nullable=False)

    claimer_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    reason = db.Column(db.Text, nullable=False)

    status = db.Column(db.String(20), nullable=False, default=ClaimStatus.PENDING)

    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self, include_item=False):
        data = {
            "id": self.id,
            "item_id": self.item_id,
            "claimer_name": self.claimer_name,
            "email": self.email,
            "phone": self.phone,
            "reason": self.reason,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
        if include_item and self.item:
            data["item"] = self.item.to_dict()
        return data

    def __repr__(self):
        return f"<Claim {self.id} item={self.item_id} status={self.status}>"
