# EduInsight Syllabus Mapping

| Topic | File | Function/Class | Description |
| --- | --- | --- | --- |
| Python Functions | `app/routes.py` | `dashboard`, `analytics`, `student_detail` | Flask route functions coordinate uploads, analytics generation, search, and reports. |
| Python Functions | `app/utils/helpers.py` | `allowed_file`, `safe_percentage`, `build_grade_distribution` | Reusable helper functions support validation and summary formatting. |
| Object Oriented Programming | `app/services/data_service.py` | `StudentDataManager` | Encapsulates CSV upload, validation, cleaning, merge, and NumPy matrix preparation. |
| Object Oriented Programming | `app/services/analytics_service.py` | `StudentAnalytics` | Encapsulates analytical transformations, dashboard metrics, search, and report generation. |
| Object Oriented Programming | `app/services/visualization_service.py` | `ChartBuilder` | Encapsulates Matplotlib and Seaborn chart generation. |
| Object Oriented Programming | `app/models.py` | `StudentProfile` | Represents an individual student report as a real data model. |
| List Comprehensions | `app/services/analytics_service.py` | `search_students` | Filters student records by name or ID using a list comprehension. |
| Dictionary Comprehensions | `app/services/analytics_service.py` | `_dictionary_comprehension_summary` | Builds analytical summary metrics from subject and attendance columns. |
| NumPy Arrays | `app/services/analytics_service.py` | `prepare_dataframe` | Converts subject marks into NumPy arrays for scoring analysis. |
| Broadcasting | `app/services/analytics_service.py` | `prepare_dataframe` | Applies grace marks and normalization across whole score matrices using broadcasting. |
| Vectorized Operations | `app/services/analytics_service.py` | `prepare_dataframe` | Computes totals, averages, percentages, grades, and pass/fail results without unnecessary loops. |
| Pandas DataFrames | `app/services/data_service.py` | `load_dataset` | Reads uploaded CSV files into Pandas DataFrames. |
| Data Cleaning | `app/services/data_service.py` | `_clean_students`, `_clean_marks` | Handles missing values, duplicate rows, and type conversion. |
| Merge | `app/services/data_service.py` | `_merge_datasets` | Merges students and marks data on `Student_ID`. |
| GroupBy | `app/services/analytics_service.py` | `_group_summary` | Creates class-wise, section-wise, and gender-wise performance summaries. |
| Matplotlib | `app/services/visualization_service.py` | `_subject_bar_chart`, `_result_pie_chart`, `_percentage_histogram`, `_attendance_scatter`, `_class_line_chart` | Generates bar, pie, histogram, scatter, and line charts. |
| Seaborn | `app/services/visualization_service.py` | `_correlation_heatmap`, `_subject_box_plot`, `_grade_count_plot`, `_attendance_distribution` | Generates heatmap, box plot, count plot, and distribution plot. |
