﻿from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import shutil

import numpy as np
import pandas as pd
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename

from app.utils.helpers import allowed_file


class StudentDataManager:
    def __init__(self, upload_folder: Path, subject_columns: list[str], allowed_extensions: set[str]):
        self.upload_folder = Path(upload_folder)
        self.subject_columns = subject_columns
        self.allowed_extensions = allowed_extensions
        self.upload_folder.mkdir(parents=True, exist_ok=True)

    def clear_existing_uploads(self) -> None:
        if self.upload_folder.exists():
            for file_path in self.upload_folder.glob("*.csv"):
                file_path.unlink(missing_ok=True)

    def save_upload(self, file_storage: FileStorage, target_name: str) -> Path:
        if not file_storage or not file_storage.filename:
            raise ValueError(f"{target_name} file is required.")
        if not allowed_file(file_storage.filename, self.allowed_extensions):
            raise ValueError(f"{target_name} must be a CSV file.")

        sanitized_name = secure_filename(target_name)
        target_path = self.upload_folder / sanitized_name
        file_storage.save(target_path)
        return target_path

    def load_dataset(self) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        students_path = self.upload_folder / "students.csv"
        marks_path = self.upload_folder / "marks.csv"

        if not students_path.exists() or not marks_path.exists():
            raise FileNotFoundError("Upload both students.csv and marks.csv to continue.")

        students_df = pd.read_csv(students_path)
        marks_df = pd.read_csv(marks_path)

        clean_students = self._clean_students(students_df)
        clean_marks = self._clean_marks(marks_df)
        merged_df = self._merge_datasets(clean_students, clean_marks)

        return clean_students, clean_marks, merged_df

    def reset_workspace(self, chart_folder: Path | None = None) -> None:
        self.clear_existing_uploads()
        if chart_folder and Path(chart_folder).exists():
            shutil.rmtree(chart_folder, ignore_errors=True)

    def _clean_students(self, students_df: pd.DataFrame) -> pd.DataFrame:
        required_columns = ["Student_ID", "Name", "Gender", "Class", "Section"]
        self._validate_columns(students_df, required_columns, "students.csv")

        cleaned = students_df.copy()
        cleaned.columns = [column.strip() for column in cleaned.columns]
        cleaned = cleaned.drop_duplicates(subset=["Student_ID"]).copy()
        cleaned["Student_ID"] = cleaned["Student_ID"].astype(str).str.strip()
        cleaned["Name"] = cleaned["Name"].fillna("Unknown Student").astype(str).str.strip()
        cleaned["Gender"] = cleaned["Gender"].fillna("Unknown").astype(str).str.strip().str.title()
        cleaned["Class"] = cleaned["Class"].fillna("Unknown").astype(str).str.strip()
        cleaned["Section"] = cleaned["Section"].fillna("NA").astype(str).str.strip().str.upper()
        return cleaned

    def _clean_marks(self, marks_df: pd.DataFrame) -> pd.DataFrame:
        required_columns = ["Student_ID", *self.subject_columns, "Attendance"]
        self._validate_columns(marks_df, required_columns, "marks.csv")

        cleaned = marks_df.copy()
        cleaned.columns = [column.strip() for column in cleaned.columns]
        cleaned["Student_ID"] = cleaned["Student_ID"].astype(str).str.strip()

        numeric_columns = [*self.subject_columns, "Attendance"]
        for column in numeric_columns:
            cleaned[column] = pd.to_numeric(cleaned[column], errors="coerce")

        cleaned[numeric_columns] = cleaned[numeric_columns].fillna(cleaned[numeric_columns].median(numeric_only=True))
        cleaned[self.subject_columns] = cleaned[self.subject_columns].clip(0, 100)
        cleaned["Attendance"] = cleaned["Attendance"].clip(0, 100)
        cleaned = cleaned.drop_duplicates(subset=["Student_ID"]).copy()

        return cleaned

    def _merge_datasets(self, students_df: pd.DataFrame, marks_df: pd.DataFrame) -> pd.DataFrame:
        merged = pd.merge(students_df, marks_df, on="Student_ID", how="inner")
        if merged.empty:
            raise ValueError("No common Student_ID values were found after merge.")
        return merged

    @staticmethod
    def _validate_columns(dataframe: pd.DataFrame, required_columns: list[str], dataset_name: str) -> None:
        missing_columns = [column for column in required_columns if column not in dataframe.columns]
        if missing_columns:
            raise ValueError(f"{dataset_name} is missing columns: {', '.join(missing_columns)}")

    def has_uploaded_files(self) -> bool:
        return (self.upload_folder / "students.csv").exists() and (self.upload_folder / "marks.csv").exists()

    def build_subject_matrix(self, merged_df: pd.DataFrame) -> np.ndarray:
        return merged_df[self.subject_columns].to_numpy(dtype=float)

    @staticmethod
    def cleanup_old_session_data(*roots: Path, ttl_hours: int) -> None:
        cutoff = datetime.now() - timedelta(hours=ttl_hours)
        for root in roots:
            root_path = Path(root)
            root_path.mkdir(parents=True, exist_ok=True)
            for child in root_path.iterdir():
                try:
                    modified_time = datetime.fromtimestamp(child.stat().st_mtime)
                    if modified_time < cutoff:
                        if child.is_dir():
                            shutil.rmtree(child, ignore_errors=True)
                        else:
                            child.unlink(missing_ok=True)
                except FileNotFoundError:
                    continue
