﻿from __future__ import annotations

import hashlib
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from app.utils.helpers import ensure_chart_directory


class ChartBuilder:
    def __init__(self, chart_folder: Path, subject_columns: list[str], web_prefix: str):
        self.chart_folder = Path(chart_folder)
        self.subject_columns = subject_columns
        self.web_prefix = web_prefix.strip("/")
        self.chart_definitions = [
            ("subject_bar_chart.png", "Subject Performance", "Matplotlib Bar Chart", self._subject_bar_chart),
            ("result_pie_chart.png", "Pass and Fail Split", "Matplotlib Pie Chart", self._result_pie_chart),
            ("percentage_histogram.png", "Percentage Distribution", "Matplotlib Histogram", self._percentage_histogram),
            ("attendance_scatter.png", "Attendance Correlation", "Matplotlib Scatter Plot", self._attendance_scatter),
            ("class_line_chart.png", "Class Trend", "Matplotlib Line Chart", self._class_line_chart),
            ("correlation_heatmap.png", "Correlation Heatmap", "Seaborn Heatmap", self._correlation_heatmap),
            ("subject_box_plot.png", "Score Spread", "Seaborn Box Plot", self._subject_box_plot),
            ("grade_count_plot.png", "Grade Distribution", "Seaborn Count Plot", self._grade_count_plot),
            ("attendance_distribution.png", "Attendance Distribution", "Seaborn Distribution Plot", self._attendance_distribution),
        ]
        ensure_chart_directory(self.chart_folder)
        sns.set_theme(style="whitegrid", palette="Blues")

    def generate_all(self, prepared_df: pd.DataFrame) -> list[dict[str, str]]:
        data_signature = self._build_signature(prepared_df)
        charts = self._build_chart_manifest()

        if self._charts_are_cached(charts, data_signature):
            return charts

        for filename, title, chart_type, builder in self.chart_definitions:
            builder(prepared_df, filename, title, chart_type)

        (self.chart_folder / ".signature").write_text(data_signature, encoding="utf-8")
        return charts

    def _build_signature(self, prepared_df: pd.DataFrame) -> str:
        hashed = pd.util.hash_pandas_object(prepared_df, index=True).values.tobytes()
        return hashlib.sha256(hashed).hexdigest()

    def _build_chart_manifest(self) -> list[dict[str, str]]:
        return [
            {
                "filename": filename,
                "title": title,
                "chart_type": chart_type,
                "web_path": f"{self.web_prefix}/{filename}",
            }
            for filename, title, chart_type, _ in self.chart_definitions
        ]

    def _charts_are_cached(self, charts: list[dict[str, str]], data_signature: str) -> bool:
        signature_file = self.chart_folder / ".signature"
        if not signature_file.exists():
            return False
        if signature_file.read_text(encoding="utf-8") != data_signature:
            return False
        return all((self.chart_folder / chart["filename"]).exists() for chart in charts)

    def _save_figure(self, filename: str, title: str, chart_type: str) -> dict[str, str]:
        plt.tight_layout()
        file_path = self.chart_folder / filename
        plt.savefig(file_path, dpi=150, bbox_inches="tight")
        plt.close()
        return {
            "filename": filename,
            "title": title,
            "chart_type": chart_type,
            "web_path": f"{self.web_prefix}/{filename}",
        }

    def _subject_bar_chart(self, prepared_df: pd.DataFrame, filename: str, title: str, chart_type: str) -> dict[str, str]:
        averages = prepared_df[self.subject_columns].mean().sort_values(ascending=False)
        plt.figure(figsize=(7.2, 4.2))
        plt.bar(averages.index, averages.values, color=["#5b8db5", "#77a4c7", "#96b9d6", "#b8d1e4"])
        plt.title("Subject-wise Average Scores")
        plt.ylabel("Average Marks")
        return self._save_figure(filename, title, chart_type)

    def _result_pie_chart(self, prepared_df: pd.DataFrame, filename: str, title: str, chart_type: str) -> dict[str, str]:
        result_counts = prepared_df["Result"].value_counts()
        plt.figure(figsize=(5.8, 5.8))
        plt.pie(result_counts.values, labels=result_counts.index, autopct="%1.1f%%", startangle=120, colors=["#7fb39a", "#d98b73"])
        plt.title("Pass vs Fail Distribution")
        return self._save_figure(filename, title, chart_type)

    def _percentage_histogram(self, prepared_df: pd.DataFrame, filename: str, title: str, chart_type: str) -> dict[str, str]:
        plt.figure(figsize=(7.2, 4.2))
        plt.hist(prepared_df["Percentage"], bins=12, color="#5b8db5", edgecolor="white")
        plt.title("Percentage Distribution")
        plt.xlabel("Percentage")
        plt.ylabel("Students")
        return self._save_figure(filename, title, chart_type)

    def _attendance_scatter(self, prepared_df: pd.DataFrame, filename: str, title: str, chart_type: str) -> dict[str, str]:
        plt.figure(figsize=(7.2, 4.2))
        plt.scatter(prepared_df["Attendance"], prepared_df["Percentage"], color="#4d81a6", alpha=0.75)
        plt.title("Attendance vs Percentage")
        plt.xlabel("Attendance")
        plt.ylabel("Percentage")
        return self._save_figure(filename, title, chart_type)

    def _class_line_chart(self, prepared_df: pd.DataFrame, filename: str, title: str, chart_type: str) -> dict[str, str]:
        class_summary = prepared_df.groupby("Class", as_index=False)["Percentage"].mean().sort_values("Class")
        plt.figure(figsize=(7.2, 4.2))
        plt.plot(class_summary["Class"], class_summary["Percentage"], marker="o", linewidth=2.2, color="#4f8fb6")
        plt.title("Class-wise Average Percentage")
        plt.xlabel("Class")
        plt.ylabel("Average Percentage")
        return self._save_figure(filename, title, chart_type)

    def _correlation_heatmap(self, prepared_df: pd.DataFrame, filename: str, title: str, chart_type: str) -> dict[str, str]:
        plt.figure(figsize=(7.2, 4.8))
        correlation_df = prepared_df[[*self.subject_columns, "Attendance", "Percentage"]].corr(numeric_only=True)
        sns.heatmap(correlation_df, annot=True, cmap="Blues", fmt=".2f")
        plt.title("Correlation Heatmap")
        return self._save_figure(filename, title, chart_type)

    def _subject_box_plot(self, prepared_df: pd.DataFrame, filename: str, title: str, chart_type: str) -> dict[str, str]:
        plt.figure(figsize=(7.2, 4.2))
        melted = prepared_df.melt(value_vars=self.subject_columns, var_name="Subject", value_name="Marks")
        sns.boxplot(data=melted, x="Subject", y="Marks", hue="Subject", legend=False, palette="Blues")
        plt.title("Subject Score Spread")
        return self._save_figure(filename, title, chart_type)

    def _grade_count_plot(self, prepared_df: pd.DataFrame, filename: str, title: str, chart_type: str) -> dict[str, str]:
        plt.figure(figsize=(7.2, 4.2))
        sns.countplot(data=prepared_df, x="Grade", hue="Grade", legend=False, palette="Blues")
        plt.title("Grade Distribution")
        return self._save_figure(filename, title, chart_type)

    def _attendance_distribution(self, prepared_df: pd.DataFrame, filename: str, title: str, chart_type: str) -> dict[str, str]:
        plt.figure(figsize=(7.2, 4.2))
        sns.histplot(prepared_df["Attendance"], kde=True, color="#5b8db5")
        plt.title("Attendance Distribution")
        plt.xlabel("Attendance")
        return self._save_figure(filename, title, chart_type)
