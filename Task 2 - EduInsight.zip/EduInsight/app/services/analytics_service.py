from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from app.models import StudentProfile
from app.utils.helpers import build_grade_distribution, safe_percentage


@dataclass
class StudentAnalytics:
    merged_df: pd.DataFrame
    subject_columns: list[str]
    pass_mark: int
    default_grace_marks: int

    def prepare_dataframe(self) -> pd.DataFrame:
        dataframe = self.merged_df.copy()

        raw_scores = dataframe[self.subject_columns].to_numpy(dtype=float)
        subject_means = raw_scores.mean(axis=0)

        grace_matrix = np.where(raw_scores < self.pass_mark, self.default_grace_marks, 0)
        curved_scores = np.clip(raw_scores + grace_matrix, 0, 100)
        normalized_scores = np.clip((curved_scores / subject_means) * 75, 0, 100)
        final_scores = np.clip((curved_scores * 0.7) + (normalized_scores * 0.3), 0, 100)

        dataframe[self.subject_columns] = final_scores
        dataframe["Total"] = final_scores.sum(axis=1)
        dataframe["Percentage"] = (dataframe["Total"] / (len(self.subject_columns) * 100)) * 100
        dataframe["Average_Score"] = final_scores.mean(axis=1)

        conditions = [
            dataframe["Percentage"] >= 85,
            dataframe["Percentage"] >= 70,
            dataframe["Percentage"] >= 55,
            dataframe["Percentage"] >= 40,
        ]
        grade_choices = ["A+", "A", "B", "C"]
        dataframe["Grade"] = np.select(conditions, grade_choices, default="D")
        dataframe["Result"] = np.where((final_scores >= self.pass_mark).all(axis=1), "Pass", "Fail")

        return dataframe

    def build_dashboard_metrics(self, prepared_df: pd.DataFrame) -> dict[str, float | int | str]:
        subject_averages = prepared_df[self.subject_columns].mean().sort_values(ascending=False)
        pass_count = int((prepared_df["Result"] == "Pass").sum())
        fail_count = int((prepared_df["Result"] == "Fail").sum())
        total_students = int(len(prepared_df))

        metrics = {
            "total_students": total_students,
            "average_percentage": safe_percentage(prepared_df["Percentage"].mean()),
            "highest_percentage": safe_percentage(prepared_df["Percentage"].max()),
            "lowest_percentage": safe_percentage(prepared_df["Percentage"].min()),
            "pass_percentage": safe_percentage((pass_count / total_students) * 100) if total_students else 0,
            "fail_percentage": safe_percentage((fail_count / total_students) * 100) if total_students else 0,
            "average_attendance": safe_percentage(prepared_df["Attendance"].mean()),
            "top_subject": str(subject_averages.index[0]) if not subject_averages.empty else "NA",
            "weakest_subject": str(subject_averages.index[-1]) if not subject_averages.empty else "NA",
        }
        return metrics

    def build_analytics_payload(self, prepared_df: pd.DataFrame) -> dict[str, object]:
        subject_scores = prepared_df[self.subject_columns]
        analytics_summary = {
            "class_performance": self._group_summary(prepared_df, "Class"),
            "section_performance": self._group_summary(prepared_df, "Section"),
            "gender_performance": self._group_summary(prepared_df, "Gender"),
            "subject_performance": {subject: safe_percentage(value) for subject, value in subject_scores.mean().to_dict().items()},
            "attendance_analysis": {
                "average_attendance": safe_percentage(prepared_df["Attendance"].mean()),
                "high_attendance_students": int((prepared_df["Attendance"] >= 90).sum()),
                "low_attendance_students": int((prepared_df["Attendance"] < 75).sum()),
            },
            "top_students": prepared_df.nlargest(5, "Percentage")[["Student_ID", "Name", "Class", "Section", "Percentage", "Grade"]].to_dict("records"),
            "lowest_students": prepared_df.nsmallest(5, "Percentage")[["Student_ID", "Name", "Class", "Section", "Percentage", "Grade"]].to_dict("records"),
            "grade_distribution": build_grade_distribution(prepared_df["Grade"]),
            "insight_cards": self._dictionary_comprehension_summary(prepared_df),
        }
        return analytics_summary

    def build_student_profiles(self, prepared_df: pd.DataFrame) -> list[StudentProfile]:
        return [StudentProfile.from_series(row) for _, row in prepared_df.iterrows()]

    def search_students(self, prepared_df: pd.DataFrame, query: str) -> list[dict[str, object]]:
        searchable_students = [
            row
            for row in prepared_df.to_dict("records")
            if query.lower() in str(row["Name"]).lower() or query.lower() in str(row["Student_ID"]).lower()
        ]
        return searchable_students

    def get_student_profile(self, prepared_df: pd.DataFrame, student_id: str) -> StudentProfile | None:
        matched_rows = prepared_df.loc[prepared_df["Student_ID"].astype(str) == str(student_id)]
        if matched_rows.empty:
            return None
        return StudentProfile.from_series(matched_rows.iloc[0])

    def _group_summary(self, prepared_df: pd.DataFrame, group_column: str) -> list[dict[str, object]]:
        grouped = (
            prepared_df.groupby(group_column)
            .agg(
                Average_Percentage=("Percentage", "mean"),
                Average_Attendance=("Attendance", "mean"),
                Students=("Student_ID", "count"),
            )
            .reset_index()
            .sort_values("Average_Percentage", ascending=False)
        )
        grouped["Average_Percentage"] = grouped["Average_Percentage"].round(2)
        grouped["Average_Attendance"] = grouped["Average_Attendance"].round(2)
        return grouped.to_dict("records")

    def _dictionary_comprehension_summary(self, prepared_df: pd.DataFrame) -> dict[str, float]:
        return {
            column: safe_percentage(prepared_df[column].mean())
            for column in [*self.subject_columns, "Attendance", "Percentage"]
        }
