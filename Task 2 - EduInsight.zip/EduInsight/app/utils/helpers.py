from __future__ import annotations

from pathlib import Path
from typing import Iterable


def allowed_file(filename: str, allowed_extensions: set[str]) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in allowed_extensions


def safe_percentage(value: float) -> float:
    return round(float(value), 2)


def ensure_chart_directory(chart_dir: Path) -> None:
    chart_dir.mkdir(parents=True, exist_ok=True)


def format_label(value: str) -> str:
    return value.replace("_", " ").title()


def build_grade_distribution(grades: Iterable[str]) -> dict[str, int]:
    return {grade: list(grades).count(grade) for grade in sorted(set(grades))}
