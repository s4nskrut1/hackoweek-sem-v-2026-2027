﻿from __future__ import annotations

from pathlib import Path
from uuid import uuid4

from flask import Blueprint, current_app, flash, redirect, render_template, request, session, url_for

from app.services.analytics_service import StudentAnalytics
from app.services.data_service import StudentDataManager
from app.services.visualization_service import ChartBuilder

main_bp = Blueprint("main", __name__)


def get_session_key() -> str:
    session_key = session.get("analysis_session_id")
    if not session_key:
        session_key = uuid4().hex
        session["analysis_session_id"] = session_key
    return session_key


def build_session_paths() -> tuple[str, Path, Path, str]:
    session_key = get_session_key()
    upload_root = Path(current_app.config["SESSION_UPLOAD_ROOT"])
    chart_root = Path(current_app.config["SESSION_CHART_ROOT"])
    upload_folder = upload_root / session_key
    chart_folder = chart_root / session_key
    chart_web_prefix = f"charts/sessions/{session_key}"
    return session_key, upload_folder, chart_folder, chart_web_prefix


def get_services():
    StudentDataManager.cleanup_old_session_data(
        Path(current_app.config["SESSION_UPLOAD_ROOT"]),
        Path(current_app.config["SESSION_CHART_ROOT"]),
        ttl_hours=current_app.config["SESSION_DATA_TTL_HOURS"],
    )

    _, upload_folder, chart_folder, chart_web_prefix = build_session_paths()

    data_manager = StudentDataManager(
        upload_folder=upload_folder,
        subject_columns=current_app.config["SUBJECT_COLUMNS"],
        allowed_extensions=current_app.config["ALLOWED_EXTENSIONS"],
    )

    analytics = None
    prepared_df = None
    raw_students = None
    raw_marks = None
    chart_builder = ChartBuilder(
        chart_folder=chart_folder,
        subject_columns=current_app.config["SUBJECT_COLUMNS"],
        web_prefix=chart_web_prefix,
    )

    if data_manager.has_uploaded_files():
        raw_students, raw_marks, merged_df = data_manager.load_dataset()
        analytics = StudentAnalytics(
            merged_df=merged_df,
            subject_columns=current_app.config["SUBJECT_COLUMNS"],
            pass_mark=current_app.config["PASS_MARK"],
            default_grace_marks=current_app.config["DEFAULT_GRACE_MARKS"],
        )
        prepared_df = analytics.prepare_dataframe()

    return data_manager, analytics, chart_builder, raw_students, raw_marks, prepared_df


@main_bp.route("/")
def index():
    data_manager, _, _, _, _, prepared_df = get_services()
    dataset_ready = data_manager.has_uploaded_files() and prepared_df is not None
    return render_template("index.html", dataset_ready=dataset_ready)


@main_bp.route("/upload", methods=["GET", "POST"])
def upload():
    data_manager, _, _, _, _, _ = get_services()

    if request.method == "POST":
        try:
            _, _, chart_folder, _ = build_session_paths()
            data_manager.reset_workspace(chart_folder=chart_folder)
            data_manager.save_upload(request.files.get("students_file"), "students.csv")
            data_manager.save_upload(request.files.get("marks_file"), "marks.csv")
            flash("CSV files uploaded successfully. Analytics are ready for this session.", "success")
            return redirect(url_for("main.dashboard"))
        except Exception as exc:
            flash(str(exc), "danger")

    return render_template("upload.html", dataset_ready=data_manager.has_uploaded_files())


@main_bp.route("/reset", methods=["POST"])
def reset_analysis():
    data_manager, _, _, _, _, _ = get_services()
    _, _, chart_folder, _ = build_session_paths()
    data_manager.reset_workspace(chart_folder=chart_folder)
    session.pop("analysis_session_id", None)
    flash("Analysis cleared. You now have a fresh workspace.", "success")
    return redirect(url_for("main.upload"))


@main_bp.route("/dashboard")
def dashboard():
    data_manager, analytics, chart_builder, raw_students, raw_marks, prepared_df = get_services()
    if not data_manager.has_uploaded_files() or analytics is None or prepared_df is None:
        flash("Upload students.csv and marks.csv to unlock the dashboard.", "warning")
        return redirect(url_for("main.upload"))

    metrics = analytics.build_dashboard_metrics(prepared_df)
    charts = chart_builder.generate_all(prepared_df)
    student_records = prepared_df.sort_values("Percentage", ascending=False).to_dict("records")

    return render_template(
        "dashboard.html",
        metrics=metrics,
        charts=charts,
        students=student_records,
        raw_counts={"students": len(raw_students), "marks": len(raw_marks)},
    )


@main_bp.route("/analytics")
def analytics():
    data_manager, analytics_service, chart_builder, _, _, prepared_df = get_services()
    if not data_manager.has_uploaded_files() or analytics_service is None or prepared_df is None:
        flash("Upload both CSV files before opening analytics.", "warning")
        return redirect(url_for("main.upload"))

    analytics_payload = analytics_service.build_analytics_payload(prepared_df)
    charts = chart_builder.generate_all(prepared_df)

    return render_template("analytics.html", analytics=analytics_payload, charts=charts)


@main_bp.route("/students")
def students():
    data_manager, analytics_service, _, _, _, prepared_df = get_services()
    if not data_manager.has_uploaded_files() or analytics_service is None or prepared_df is None:
        flash("Upload both CSV files before searching students.", "warning")
        return redirect(url_for("main.upload"))

    query = request.args.get("q", "").strip()
    results = analytics_service.search_students(prepared_df, query) if query else prepared_df.sort_values("Name").to_dict("records")

    return render_template("students.html", students=results, query=query)


@main_bp.route("/student/<student_id>")
def student_detail(student_id: str):
    data_manager, analytics_service, _, _, _, prepared_df = get_services()
    if not data_manager.has_uploaded_files() or analytics_service is None or prepared_df is None:
        flash("Upload both CSV files before opening student reports.", "warning")
        return redirect(url_for("main.upload"))

    profile = analytics_service.get_student_profile(prepared_df, student_id)
    if profile is None:
        return render_template("404.html"), 404

    subject_scores = {
        "Maths": round(profile.maths, 2),
        "Science": round(profile.science, 2),
        "English": round(profile.english, 2),
        "Computer": round(profile.computer, 2),
    }

    return render_template("student_detail.html", profile=profile, subject_scores=subject_scores)


@main_bp.route("/about")
def about():
    syllabus_topics = [
        "Python Functions",
        "Object Oriented Programming",
        "List and Dictionary Comprehensions",
        "NumPy Arrays, Broadcasting, and Vectorized Operations",
        "Pandas Cleaning, Merge, and GroupBy",
        "Matplotlib and Seaborn Visualizations",
    ]
    return render_template("about.html", syllabus_topics=syllabus_topics)


@main_bp.app_errorhandler(404)
def not_found(_error):
    return render_template("404.html"), 404
