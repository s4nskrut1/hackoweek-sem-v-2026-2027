﻿from pathlib import Path

from flask import Flask

from .routes import main_bp


def create_app() -> Flask:
    app = Flask(__name__)
    app.config.from_object("app.config.Config")

    Path(app.config["UPLOAD_FOLDER"]).mkdir(parents=True, exist_ok=True)
    Path(app.config["CHART_FOLDER"]).mkdir(parents=True, exist_ok=True)
    Path(app.config["SESSION_UPLOAD_ROOT"]).mkdir(parents=True, exist_ok=True)
    Path(app.config["SESSION_CHART_ROOT"]).mkdir(parents=True, exist_ok=True)

    app.register_blueprint(main_bp)

    return app
