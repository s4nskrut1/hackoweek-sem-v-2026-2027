﻿from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent.parent


class Config:
    SECRET_KEY = "eduinsight-secret-key"
    BASE_DIR = BASE_DIR
    DATA_DIR = BASE_DIR / "data"
    UPLOAD_FOLDER = DATA_DIR / "uploads"
    CHART_FOLDER = BASE_DIR / "app" / "static" / "charts"
    SESSION_UPLOAD_ROOT = UPLOAD_FOLDER / "sessions"
    SESSION_CHART_ROOT = CHART_FOLDER / "sessions"
    ALLOWED_EXTENSIONS = {"csv"}
    SUBJECT_COLUMNS = ["Maths", "Science", "English", "Computer"]
    PASS_MARK = 40
    DEFAULT_GRACE_MARKS = 5
    SESSION_DATA_TTL_HOURS = 6
