from dataclasses import dataclass
from typing import Any


@dataclass
class StudentProfile:
    student_id: str
    name: str
    gender: str
    class_name: str
    section: str
    maths: float
    science: float
    english: float
    computer: float
    attendance: float
    percentage: float
    grade: str
    result: str

    @classmethod
    def from_series(cls, row: Any) -> "StudentProfile":
        return cls(
            student_id=str(row["Student_ID"]),
            name=str(row["Name"]),
            gender=str(row["Gender"]),
            class_name=str(row["Class"]),
            section=str(row["Section"]),
            maths=float(row["Maths"]),
            science=float(row["Science"]),
            english=float(row["English"]),
            computer=float(row["Computer"]),
            attendance=float(row["Attendance"]),
            percentage=float(row["Percentage"]),
            grade=str(row["Grade"]),
            result=str(row["Result"]),
        )
