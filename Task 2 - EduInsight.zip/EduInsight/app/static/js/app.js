document.addEventListener("DOMContentLoaded", () => {
    const metricCards = document.querySelectorAll(".metric-card, .panel-card, .info-card");

    metricCards.forEach((card, index) => {
        card.style.opacity = "0";
        card.style.transform = "translateY(14px)";
        setTimeout(() => {
            card.style.transition = "opacity 0.45s ease, transform 0.45s ease";
            card.style.opacity = "1";
            card.style.transform = "translateY(0)";
        }, 80 * index);
    });
});
